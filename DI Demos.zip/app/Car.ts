import { Injectable } from "@angular/core";
import { Engine } from "./Engine";
 
 

@Injectable() // this makes FuelType as a service class
export class Car
{
    carType:string;

    constructor(private e:Engine) // DI
    {
        console.log("constructor of Car created");
        this.carType=  "this is a sedan that uses  " + this.e.engineType;
    }
}