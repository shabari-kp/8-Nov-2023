import { Injectable } from "@angular/core";
import { Piston } from "./Piston";
 
 

@Injectable() // this makes FuelType as a service class
export class Engine
{
    engineType:string;

    constructor(private p:Piston) // DI
    {
        console.log("constructor of engine created");
        this.engineType=  "bs6 " + "depends on " + this.p.text;
    }
}