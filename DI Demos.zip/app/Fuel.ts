import { Injectable } from "@angular/core";
import { FuelType } from "./FuelType";

@Injectable() // this makes FuelType as a service class
export class Fuel
{
    brandName:string;

    constructor(private ft:FuelType) // DI
    {
        console.log("constructor of Fuel created");
        this.brandName=   "shell   " + this.ft.type ;
    }
}