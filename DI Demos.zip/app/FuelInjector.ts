import { Injectable } from "@angular/core";
import { Fuel } from "./Fuel";

@Injectable() // this makes FuelType as a service class
export class FuelInjector
{
    text:string;

    constructor(private f:Fuel) // DI
    {
        console.log("constructor of FuelInjector created");
        this.text=    "fule injector is initialized with" + this.f.brandName;
    }
}