import { Injectable } from "@angular/core";

@Injectable() // this makes FuelType as a service class
export class FuelType
{
    type:string;

    constructor()
    {
        console.log("constructor of FuelType created");
        this.type="petrol";
    }
}