import { Injectable } from "@angular/core";
import { FuelInjector } from "./FuelInjector";
 

@Injectable() // this makes FuelType as a service class
export class Piston
{
    text:string;

    constructor(private fi:FuelInjector) // DI
    {
        console.log("constructor of piston created");
        this.text=     "piston uses" + this.fi.text;
    }
}