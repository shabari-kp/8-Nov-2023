import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarDemoComponent } from './car-demo/car-demo.component';
import { FuelInjector } from './FuelInjector';
import { FuelType } from './FuelType';
import { Fuel } from './Fuel';
import { Car } from './Car';
import { Engine } from './Engine';
import { Piston } from './Piston';

@NgModule({
  declarations: [
    AppComponent,
    CarDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [Car,Engine,Piston,FuelInjector,FuelType,Fuel],
  bootstrap: [AppComponent]
})
export class AppModule { }
