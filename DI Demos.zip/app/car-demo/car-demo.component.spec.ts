import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarDemoComponent } from './car-demo.component';

describe('CarDemoComponent', () => {
  let component: CarDemoComponent;
  let fixture: ComponentFixture<CarDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CarDemoComponent]
    });
    fixture = TestBed.createComponent(CarDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
