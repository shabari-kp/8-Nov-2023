import { Component } from '@angular/core';
import { Car } from '../Car';

@Component({
  selector: 'app-car-demo',
  templateUrl: './car-demo.component.html',
  styleUrls: ['./car-demo.component.css']
})
export class CarDemoComponent {
  result:string;
constructor(private c:Car)
{
    this.result=this.c.carType;
     
}
}
