import { Component ,Input,ViewChild,
ElementRef,
  OnChanges, 
  OnInit, 
  DoCheck, 
  AfterContentInit, 
  AfterContentChecked, 
  AfterViewInit, 
  AfterViewChecked, 
  OnDestroy, 
  SimpleChanges 
} from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent 
implements 
OnChanges, 
OnInit, 
DoCheck, 
AfterContentInit, 
AfterContentChecked, 
AfterViewInit, 
AfterViewChecked, OnDestroy


{
  @Input() msg:string="";


@ViewChild('d1') x:ElementRef<HTMLElement>;

  constructor() {
    console.log('[constructor of the child cmp fired]');
    console.log(`msg: ${this.msg}`);
    this.msg = 'TEST';
    console.log(`msg: ${this.msg}`);
    console.log("in constructor - accessing" + this.x);

  }

  ngOnInit() 
  {
    console.log('[OnInit fired]');
    console.log(`msg is : ${this.msg}`);
    console.log("in oninit - accessing" + this.x);
  }


  ngOnChanges(changes: SimpleChanges) {
    console.log('[OnChanges fired]');
    console.log(`prop: ${this.msg}`);
    console.log('changes:', changes);
  }
  ngDoCheck() {
    console.log('[DoCheck fired]');
  }

  ngAfterContentInit() {
    console.log('[ngAfterContentInit fired]');
  }

  ngAfterContentChecked() {
    console.log('[ngAfterContentChecked fired]');
  }

  ngAfterViewInit() {
    console.log('[ngAfterViewInit fired]');
    console.log("in viewinit - accessing" + this.x.nativeElement);
  }

  ngAfterViewChecked() {
    console.log('[ngAfterViewChecked fired]');
  }

  ngOnDestroy() {
    console.log('[ngOnDestroy fired]');
  }
}
