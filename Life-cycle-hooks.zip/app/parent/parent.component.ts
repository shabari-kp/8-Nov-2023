import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit
{
  status = false;

  name: string;
 
  constructor()
  {
    console.log("parent cmp constructor called");
    setTimeout(() => this.updateName(), 7000);
  }


 
  ngOnInit(): void
   {
    this.name="Alice";
  }

  updateName() {
    this.name = 'Bob';
  }

}
